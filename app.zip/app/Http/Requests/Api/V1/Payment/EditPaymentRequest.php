<?php

namespace App\Http\Requests\Api\V1\Payment;

use Illuminate\Foundation\Http\FormRequest;

class EditPaymentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'orderId'      => 'required|exists:orders,id',
            'invoiceId'    => 'required|exists:invoices,id',
            'method'       => 'required|string',
            'amount'       => 'required|numeric|min:1',
            'details'      => 'required|array',
        ];
    }
}
